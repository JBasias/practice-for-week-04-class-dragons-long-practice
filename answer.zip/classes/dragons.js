
  /*
  const puff = new Dragon("Puff", "green");
console.log(puff);
console.log(puff.breathesFire());
*/
/*
const puff = new Dragon("Puff", "green");
const toothless = new Dragon("Toothless", "black");
console.log(Dragon.getDragons(puff, toothless));*/
